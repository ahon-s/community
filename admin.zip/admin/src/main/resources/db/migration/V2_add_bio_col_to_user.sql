alter table user add bio varchar(255) null;

