package com.paper.admin.exception;

public interface ICustomizeErrorCode {
    String getMessage();
    Integer getCode();
}
